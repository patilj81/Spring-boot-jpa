package com.jignesh.springdatajpa.example.spring.data.jpa.example.controller;

import com.jignesh.springdatajpa.example.spring.data.jpa.example.bean.Person;
import com.jignesh.springdatajpa.example.spring.data.jpa.example.bean.PersonNotFoundException;
import com.jignesh.springdatajpa.example.spring.data.jpa.example.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * This is {@link RestController} for Person Entity
 */

@RestController
@RequestMapping("/People")
public class PersonController {

    @Autowired
    private PersonService personService;

    /**
     * This method give list of {@link Person}
     * @return list of {@link Person}
     */
    @GetMapping("")
    public List<Person> getAllPerson(){
        return personService.getAllPerson();
    }

    /**
     * This method saves new {@link Person}
     * @param person {@link Person}to save
     * @return {@link ResponseEntity}
     */
    @PostMapping("")
    public ResponseEntity<Object> saveNewPerson(@RequestBody Person person){
        Person person1 = personService.saveNewPerson(person);
        return new ResponseEntity<>("Person is created successfully with id : " + person1.getId(), HttpStatus.CREATED);
    }

    /**
     * This method to get {@link Person}
     * @param id {@link Long}id of person
     * @return {@link Person}
     * @throws PersonNotFoundException custom exception
     */
    @GetMapping("/{id}")
    public Person getPersonById(@PathVariable long id) throws PersonNotFoundException {
        return personService.getPersonById(id);
    }

    /**
     * This method to update existing {@link Person}
     * @param person {@link Person} to save
     * @param id {@link Long}id of person
     * @return {@link ResponseEntity}
     */
    @PutMapping("/{id}")
    public ResponseEntity<Object> updatePerson(@RequestBody Person person, @PathVariable long id){
        Person person1 = personService.updatePerson(person,id);
        return new ResponseEntity<>("Person is updated successfully", HttpStatus.OK);
    }


}
