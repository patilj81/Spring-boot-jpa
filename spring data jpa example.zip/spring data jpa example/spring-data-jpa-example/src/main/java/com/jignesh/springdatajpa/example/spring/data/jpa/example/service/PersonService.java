package com.jignesh.springdatajpa.example.spring.data.jpa.example.service;

import com.jignesh.springdatajpa.example.spring.data.jpa.example.bean.Person;
import com.jignesh.springdatajpa.example.spring.data.jpa.example.bean.PersonNotFoundException;
import com.jignesh.springdatajpa.example.spring.data.jpa.example.repository.PersonRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * This is the service class.
 */
@Service
public class PersonService {

    @Autowired
    private PersonRepo personRepo;

    /**
     * This method give list of {@link Person}
     * @return list of {@link Person}
     */
    @Transactional
    public List<Person> getAllPerson(){
        return personRepo.findAll();
    }

    /**
     * This method saves new {@link Person}
     * @param person {@link Person}
     * @return {@link Person}
     */
    @Transactional
    public Person saveNewPerson(@RequestBody Person person){
        return personRepo.save(person);
    }

    /**
     * This method to get {@link Person}
     * @param id {@link Long}id of person
     * @return {@link Person}
     * @throws PersonNotFoundException custom exception
     */
    @Transactional
    public Person getPersonById(@PathVariable long id) throws PersonNotFoundException {
        Optional<Person> person = personRepo.findById(id);
        if(!person.isPresent())
            throw new PersonNotFoundException("Person not found for id :" + id);
        return person.get();
    }

    /**
     * This method to update existing {@link Person}
     * @param person {@link Person} to save
     * @param id {@link Long}id of person
     * @return {@link Person}
     * @throws PersonNotFoundException custom exception
     */
    @Transactional
    public Person  updatePerson(Person person, long id) throws PersonNotFoundException {
        Optional<Person> personOptional = personRepo.findById(id);
        if(!personOptional.isPresent())
            throw new PersonNotFoundException("Person not found for id :" + id);

        person.setId(id);

        return personRepo.save(person);
    }

}
