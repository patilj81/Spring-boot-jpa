package com.jignesh.springdatajpa.example.spring.data.jpa.example.bean;

/**
 * This is Custom {@link RuntimeException}
 */
public class PersonNotFoundException extends RuntimeException {

    public PersonNotFoundException(String exception) {
        super(exception);
    }

}
