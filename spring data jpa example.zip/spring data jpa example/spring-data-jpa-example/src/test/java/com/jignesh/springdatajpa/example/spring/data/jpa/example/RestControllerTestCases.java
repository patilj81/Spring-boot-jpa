package com.jignesh.springdatajpa.example.spring.data.jpa.example;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jignesh.springdatajpa.example.spring.data.jpa.example.bean.Person;
import com.jignesh.springdatajpa.example.spring.data.jpa.example.controller.PersonController;
import com.jignesh.springdatajpa.example.spring.data.jpa.example.repository.PersonRepo;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;

import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

/**
 * This class contains unit test cases for {@link PersonController}
 */

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = PersonController.class)
public class RestControllerTestCases {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PersonRepo repo;

    @Before
    public void setUp() {

    }
    private Person getPersonObject(){
        Person person = new Person();
        person.setName("Jignesh Patil");
        person.setEmail("abc@gmail.com");
        person.setDob("02-08-1993");
        person.setCountry("IN");
        person.setAvatar("avatar");
        return person;
    }
    protected String mapToJson(Object obj) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(obj);
    }
    protected <T> T mapFromJson(String json, Class<T> clazz)
            throws IOException {

        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.readValue(json, clazz);
    }

    @Test
    public void getPersonsList() throws Exception {
        List<Person> list = new LinkedList<>();
        list.add(getPersonObject());
        Mockito.when(repo.findAll()).thenReturn(list);
        String uri = "/People";
        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(uri);
        MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();
        String output = mvcResult.getResponse().getContentAsString();
        assertEquals(output, mapToJson(list));
    }

    @Test
    public void createPerson() throws Exception {
        String uri = "/People";
        Person person = getPersonObject();
        Mockito.when(repo.save(Mockito.any())).thenReturn(person);
        String inputJson = mapToJson(person);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON).content(inputJson);
        MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();
        String content = mvcResult.getResponse().getContentAsString();
        Person person1 = mapFromJson(content, Person.class);
        assertEquals(person1.getName(),person.getName());
    }
    @Test
    public void updatePerson() throws Exception {
        String uri = "/People/0";
        Person person = getPersonObject();
        Optional<Person> optionalPerson = Optional.of(person);
        Mockito.when(repo.findById(Mockito.anyLong())).thenReturn(optionalPerson);
        Mockito.when(repo.save(Mockito.any())).thenReturn(person);
        String inputJson = mapToJson(person);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.put(uri).contentType(MediaType.APPLICATION_JSON).content(inputJson);
        MvcResult mvcResult = mockMvc.perform(requestBuilder).andReturn();
        int status = mvcResult.getResponse().getStatus();
        assertEquals(200, status);
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals(content, "Person is updated successfully");
    }
}

