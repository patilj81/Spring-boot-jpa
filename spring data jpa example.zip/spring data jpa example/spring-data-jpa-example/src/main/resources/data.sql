insert into person
values(0,'Ranga','asdasd','sadasd','sdsd','fdsdfdsf');
