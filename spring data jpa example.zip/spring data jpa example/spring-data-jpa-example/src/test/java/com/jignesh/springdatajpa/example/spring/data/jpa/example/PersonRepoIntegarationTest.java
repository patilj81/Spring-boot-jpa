package com.jignesh.springdatajpa.example.spring.data.jpa.example;

import com.jignesh.springdatajpa.example.spring.data.jpa.example.bean.Person;
import com.jignesh.springdatajpa.example.spring.data.jpa.example.repository.PersonRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * This class contains test cases for {@link PersonRepo}
 */
@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class PersonRepoIntegarationTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private PersonRepo repo;

    private Person getPersonObject(){
        Person person = new Person();
        person.setName("Jignesh Patil");
        person.setEmail("abc@gmail.com");
        person.setDob("02-08-1993");
        person.setCountry("IN");
        person.setAvatar("avatar");
        return person;
    }

    @Test
    public void getPerson(){
        Person p1 = getPersonObject();
        entityManager.persist(p1);
        Person p2  = repo.findById(p1.getId()).get();
        assertEquals(p1.getName(),p2.getName());
    }

    @Test
    public void getAllPerson(){
        Person p1 = getPersonObject();
        entityManager.persist(p1);
        List<Person> list = repo.findAll();
        assertTrue(list.size()>0);
    }
}
