package com.jignesh.springdatajpa.example.spring.data.jpa.example.repository;

import com.jignesh.springdatajpa.example.spring.data.jpa.example.bean.Person;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * This is {@link JpaRepository} for {@link Person}
 */
public interface PersonRepo extends JpaRepository<Person,Long>{}
