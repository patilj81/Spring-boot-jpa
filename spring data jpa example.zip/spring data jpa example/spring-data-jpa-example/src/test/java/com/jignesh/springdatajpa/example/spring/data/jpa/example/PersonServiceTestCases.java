package com.jignesh.springdatajpa.example.spring.data.jpa.example;

import com.jignesh.springdatajpa.example.spring.data.jpa.example.bean.Person;
import com.jignesh.springdatajpa.example.spring.data.jpa.example.bean.PersonNotFoundException;
import com.jignesh.springdatajpa.example.spring.data.jpa.example.service.PersonService;
import com.jignesh.springdatajpa.example.spring.data.jpa.example.repository.PersonRepo;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;

/**
 * This class contains test cases for {@link PersonService}
 */
@RunWith(SpringRunner.class)
public class PersonServiceTestCases {

    @InjectMocks
    private PersonService service;

    @Mock
    private PersonRepo repo;

    private Person getPersonObject(){
        Person person = new Person();
        person.setName("Jignesh Patil");
        person.setEmail("abc@gmail.com");
        person.setDob("02-08-1993");
        person.setCountry("IN");
        person.setAvatar("avatar");
        return person;
    }

    @Test
    public void getPersonsList() throws Exception {
        List<Person> list = new LinkedList<>();
        list.add(getPersonObject());
        Mockito.when(repo.findAll()).thenReturn(list);
        List list1 = service.getAllPerson();
        assertEquals(list.size(), list1.size());
    }

    @Test
    public void createPerson() throws Exception {
        Person person = getPersonObject();
        Mockito.when(repo.save(Mockito.any())).thenReturn(person);
        Person person1 = service.saveNewPerson(person);
        assertEquals(person1.getName(),person.getName());
    }
    @Test
    public void updatePerson() throws Exception {
        Person person = getPersonObject();
        person.setId(1L);
        Optional<Person> optionalPerson = Optional.of(person);
        Mockito.when(repo.findById(Mockito.anyLong())).thenReturn(optionalPerson);
        Mockito.when(repo.save(Mockito.any())).thenReturn(person);
        Person person1 = service.updatePerson(person,person.getId());
        assertEquals(person1.getId(), person.getId());
    }

    @Test(expected = PersonNotFoundException.class)
    public void personNotFoundException_Check(){
        Person person = getPersonObject();
        person.setId(1L);
        Optional<Person> optionalPerson = Optional.empty();
        Mockito.when(repo.findById(Mockito.anyLong())).thenReturn(optionalPerson);
        Mockito.when(repo.save(Mockito.any())).thenReturn(person);
        service.updatePerson(person,0L);
    }
}
